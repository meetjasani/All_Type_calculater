export const Repeatcase = [
    {
        title: "Repeating Text Generator",
        sentence: "Whether you want to input into a database, want a quick way of dispatching a lot of the same text, this online tool can prove very useful. The text repeater allows you to type your specific text you want repeating and then simply amend the settings so you can get as many 'repeated' instances of that text as you want.",
        textdata: 'Once, you’re happy with the output then you can simply copy and paste the text where you need it. If you need this repeating for several words or phrases, this can prove to be a very time efficient way of doing so. Let us know if you have any questions and recommendations on how we can improve the repeat text generator further as well.'
    }
]