export const Fbtext = [
    {
        title: "Facebook Text Generator",
        sentence: "Our Facebook Font Generator is the ideal tool for making your posts, comments, and profile stand out. With this easy-to-use generator, you can customize font type to make sure that your message grabs attention and stands out from the rest. Plus, it's % free!",
        subtitle: "Try it out now and see the difference it can make for your Facebook page. Create posts that are impossible to ignore or pass up with our one-of-a-kind text generator. Make sure your message is seen, loud and clear! It's time to stand out - start using our Font Generator.",
        text: "Simply write out your standard text on the left panel and see the different fonts generated on the right. Then select and copy the one you want to use on Facebook. If you have any questions, our customer service team is always happy to help.",
    },
]