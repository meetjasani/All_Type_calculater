
export const Onlinecal = () => {
    return (
        [
            {
                more: "Age Calculator"
            },
            {
                more: "Percentage Calculator"
            },
            {
                more: "Average Calculator"
            },
            {
                more: "Confidence Interval Calculator"
            },
            {
                more: "Sales Tax Calculator"
            },
            {
                more: "Margin Calculator"
            },
            {
                more: "Probability Calculator"
            },
            {
                more: 'Paypal Fee Calculator'
            },
            {
                more: "Discount Calculator"
            },
            {
                more: "Earnings Per Share Calculator"
            },
            {
                more: "CPM Calculator"
            },
            {
                more: "Loan To Value Calculator"
            },
            {
                more: "GST Calculator"
            },
            {
                more: "BMI Calculator"
            }
        ]
    )
}

