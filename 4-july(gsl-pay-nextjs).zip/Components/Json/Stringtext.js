export const Stringtext = [
    {
        title: "JSON Stringify Text",
        sentence: "Created by developers for developers. This JSON Stringly text generator aims to save you time when correctly formatting for Stringified Text. Simply enter the text as you would normally on the left panel.",
        subtitle: "Then as you do so, you should see the Stringified Texy version getting generated on the right hand panel then you can simply copy and paste that across.",
        text: "So you should see where there are new lines these get the /n symbols generated as well as tabs being converted to /t symbols and the whole quote gets wrapped up in speech marks. As always, please do let us know if you have any potential questions with regards to the JSON Stringify text generator and we will be more than happy to help you further and if you have any recommendations of your own on how we can improve the tool, we’d love to hear them.",
    },
]