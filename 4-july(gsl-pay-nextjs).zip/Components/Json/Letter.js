export const Letter = [
    {
        albhabet: "A",
        morsecode: ".-"
    },
    {
        albhabet: "B",
        morsecode: "-..."
    },
    {
        albhabet: "C",
        morsecode: "-.-."
    },
    {
        albhabet: "D",
        morsecode: "-.."
    },
    {
        albhabet: "E",
        morsecode: "."
    },
    {
        albhabet: "F",
        morsecode: "..-."
    },
    {
        albhabet: "G",
        morsecode: "--."
    },
    {
        albhabet: "H",
        morsecode: "...."
    },
    {
        albhabet: "I",
        morsecode: ".."
    },
    {
        albhabet: "J",
        morsecode: ".---"
    },
    {
        albhabet: "K",
        morsecode: "-.-"
    },
    {
        albhabet: "L",
        morsecode: ".-.."
    },
    {
        albhabet: "M",
        morsecode: "--"
    },


]