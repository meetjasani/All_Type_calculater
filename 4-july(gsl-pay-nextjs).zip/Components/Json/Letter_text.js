export const Letter_text = [
    {
        series: "N",
        mrscode: "-."
    },
    {
        series: "O",
        mrscode: "---"
    },
    {
        series: "P",
        mrscode: ".--."
    },
    {
        series: "Q",
        mrscode: "--.-"
    },
    {
        series: "R",
        mrscode: ".-."
    },
    {
        series: "S",
        mrscode: "..."
    },
    {
        series: "T",
        mrscode: "-"
    },
    {
        series: "U",
        mrscode: "..-"
    },
    {
        series: "V",
        mrscode: "...-"
    },
    {
        series: "W",
        mrscode: ".--"
    },
    {
        series: "X",
        mrscode: "-..-"
    },
    {
        series: "Y",
        mrscode: "-.--"
    },
    {
        series: "Z",
        mrscode: "--.."
    },
]