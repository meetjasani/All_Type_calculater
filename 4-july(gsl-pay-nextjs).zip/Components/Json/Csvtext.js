export const Csvtext = [
    {
        title: "What does the CSV to JSON converter do?",
        sentence: "Whether you have some JSON code or some CSV code that you want converting int the new format, you can use the tool above to automatically do that for you.",
        subtitle: "Simply copy the data you have into the above field, JSON code into the JSON field and the CSV data into the CSV field and then you can see it automatically be converted into your desired format in the field next to it. Copy it and then paste it where you need to.",
        text: "If you have any questions about the converter or even have some suggestions on how we can improve it further, then we’d love to hear about it.",
        covert: "Check out our other text tools as well such as our small text generator and wide text generator.",
    },
]