export const Number_text = [
    {
        no: 6,
        nocode: "-...."
    },
    {
        no: 7,
        nocode: "--..."
    },
    {
        no: 8,
        nocode: "---.."
    },
    {
        no: 9,
        nocode: "----."
    },
    {
        no: 0,
        nocode: "-----"
    }
]