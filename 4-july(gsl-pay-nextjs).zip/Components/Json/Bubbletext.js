export const Bubbletext = [
    {
        title: "Bubble Text Maker",
        sentence: "TAre you wanting to write up some content in a classic fun bubble font? Whether you want to post this in a blog post or a social media post, using this online tool as a quick ‘go to’ is certainly a great way to go about it.",
        subtitle: "Either just type away the original content that you want to turn up in the bubble font or you can copy and pate the content that you want converting. Be sure to do this in the left panel and you will see it automatically convert to the bubble text in the right panel.",
        text: "Once this is done, you should be able to see a few fonts available. Simply copy the bubble font text that you want to work and and you can then paste that where you need to. If you make a spelling mistake, you should be able to fix this pretty quick as well. You can simply just download the text straight to your computer or just copy it to the clipboard.",
        textdata: 'If you do have any potential questions about our bubble text converter then please reach out to us and we will be more than happy to help you further.',
        simple: "🅣🅗🅘🅢 🅘🅢 🅐🅝 🅔🅧🅐🅜🅟🅛🅔 🅞🅕 🅑🅤🅑🅑🅛🅔 🅣🅔🅧🅣.",
    }
]