export const Notepad = [
    {
        datalang: "English",
    },
    {
        datalang: "Deutsch",
    },
    {
        datalang: "Italiano",
    },
    {
        datalang: "Українська"
    },
    {
        datalang: "Русский"
    },
    {
        datalang: "Ελληνικά"
    }
]
