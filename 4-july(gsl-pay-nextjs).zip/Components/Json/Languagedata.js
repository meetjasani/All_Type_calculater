export const Languagedata = [
    {
        country: "English"
    },
    {
        country: "Português"
    },
    {
        country: "Español"
    },
    {
        country: "Français"
    },
    {
        country: "Русский"
    },
    {
        country: "Italiano"
    },
    {
        country: "Polski"
    },
    {
        country: "Deutsch"
    },
    {
        country: "Ελληνικά"
    },
    {
        country: "Türkçe"
    },
    {
        country: "Magyar"
    },
    {
        country: "Українська"
    },
]