export const Usertext = [
    {
        text: "Sentence case"
    },
    {
        text: "lower case"
    },
    {
        text: "UPPER CASE"
    },
    {
        text: "Capitalized Case"
    },
    {
        text: "aLtErNaTiNg cAsE"
    },
    {
        text: "Title Case"
    },
    {
        text: "InVeRsE CaSe"
    },
    {
        text: "Download Text"
    },
    {
        text: "Copy to Clipboard"
    },
    {
        text: "Clear"
    },
]