export const Numberrow = [
    {
        number: 1,
        code: ".----"
    },
    {
        number: 2,
        code: "..---"
    },
    {
        number: 3,
        code: "...--"
    },
    {
        number: 4,
        code: "....-"
    },
    {
        number: 5,
        code: "....."
    }
]