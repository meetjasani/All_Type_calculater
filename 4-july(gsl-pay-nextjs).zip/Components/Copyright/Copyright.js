import React from "react"
import Link from "next/link"
import google from "../../Assets/Images/chrome.png"
import Image from "next/image"

const Copyright = () => {
    return (
        <div>
            {/* <div className="">
                <ul className="flex flex-wrap items-center justify-center gap-1 mb-[5px]">

                    <li>
                        <Link
                            href="/"
                            className="bg-[#3b5998] text-white py-[5px] px-2 font-bold text-sm"
                        >
                            Share on Facebook
                        </Link>
                    </li>
                    <li>
                        <Link
                            href=""
                            className="bg-[#147ac8] text-white py-[5px] px-2 font-bold text-sm"
                        >
                            Tweet
                        </Link>
                    </li>
                    <li>
                        <Link
                            href=""
                            className="bg-[#ffa700] text-[#111] py-[5px] px-2 font-bold text-sm flex items-center"
                        >
                            <Image src={google} className="h-4 w-auto"></Image> Browser
                            Extensions
                        </Link>
                    </li>
                    <li>
                        <Link
                            href=""
                            className="bg-[#1e477a] text-white py-[5px] px-2 font-bold text-sm"
                        >
                            Donate with PayPal
                        </Link>
                    </li>

                    <li>
                        <Link
                            href=""
                            className="bg-[#066] text-white py-[5px] px-2 font-bold text-sm"
                        >
                            Travel & Code
                        </Link>
                    </li>
                    <li>
                        <Link
                            href=""
                            className="bg-[#62ba59] text-white py-[5px] px-2 font-bold text-sm"
                        >
                            Kyiv Guide
                        </Link>
                    </li>
                    <li>
                        <Link
                            href=""
                            className="bg-[#111] text-white py-[5px] px-2 font-bold text-sm"
                        >
                            Random Generator
                        </Link>
                    </li>

                </ul>
                <div className="flex flex-wrap items-center justify-center">
                    <p className="text-[14px] sm:text-sm lg:text-base">
                        Copyright ©2006-2023 Convert Case Ltd | Concept by |
                    </p>
                    <Link
                        href="https://jasongillyon.co.uk/"
                        target="_blank"
                        className="text-[#1f71ffe8] text-[12px] sm:text-sm md:text-base underline mx-[3px]"
                    >
                        Jason Gillyon |
                    </Link>
                    <Link
                        href="https://jasongillyon.co.uk/"
                        target="_blank"
                        className="text-[#1f71ffe8]  text-[12px] sm:text-sm md:text-base underline mx-[3px]"
                    >
                        Privacy Policy |
                    </Link>
                    <Link
                        href="https://jasongillyon.co.uk/"
                        target="_blank"
                        className="text-[#1f71ffe8]   text-[12px] sm:text-sm md:text-base underline mx-[3px]"
                    >
                        Terms of Use |
                    </Link>


                    <Link
                        href="https://jasongillyon.co.uk/"
                        target="_blank"
                        className="text-[#1f71ffe8]  text-[12px] sm:text-sm md:text-base underline mx-[3px]"
                    >
                        Sitemap |
                    </Link>
                    <Link
                        href="https://jasongillyon.co.uk/"
                        target="_blank"
                        className="text-[#1f71ffe8]  text-[12px] sm:text-sm md:text-base underline mx-[3px]"
                    >
                        About |
                    </Link>
                    <p className="mx-[3px]">Theme:</p>
                    <Link
                        href="https://jasongillyon.co.uk/"
                        target="_blank"
                        className="text-[#1f71ffe8]  text-[12px] sm:text-sm md:text-base underline"
                    >
                        Light
                    </Link>
                </div>
            </div> */}
        </div>
    )
}

export default Copyright
