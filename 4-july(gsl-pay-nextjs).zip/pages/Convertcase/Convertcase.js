import React from 'react'
import Diffrenttext from '../Diffrenttext/Diffrenttext'
import Language from '../Language/Language'

const Convertcase = () => {
    return (
        <div> <div className='mainbg max-w-[1260px] m-auto'>
            <Diffrenttext />
            <Language />
        </div></div>
    )
}

export default Convertcase