import React from 'react'
import Image from 'next/image'
// import smalltext from "../../Assets/Images/small_text_generator.png"

const Mainpage = () => {
    return (
        <div className='bg-white border border-[#E3E7ED]'>
            {/* <div className='max-w-[1260px] m-auto p-6 text-center'>
                <h1 className='text-[#e27235] font-bold text-4xl'>Text Analysis Tools</h1>
                <div className='flex items-center flex-wrap'>
                    <button>
                        <div className='iconbtn bg-[#ffede4] rounded-full h-[85px] m-auto w-[85px] flex items-center justify-center'>
                            <Image className="w-[40px]" src={smalltext}></Image>
                        </div>
                        <h3 className='text-[17px] font-semibold max-w-[100px] m-auto'>Small text Generator</h3>
                    </button>
                </div>
            </div> */}
        </div>
    )
}

export default Mainpage